require 'math'
require 'Libraries/class'
require 'Libraries/helpers'
require 'Libraries/TDungeonCell'


TDungeon = {}
TDungeon = class()

rnd = Random.new()

---------------------------------------------------------
-- CONTRUCTOR 
---------------------------------------------------------
function TDungeon:New(w,h,rndSeed,useSeed)


	-- properties
	
	self.startSide = eStartSide.TOP
	self.rndStartSide = false
	self.current_cell = Vec2.new(0,0)	
	self.addExtendedCells = false
	self.extendedCellsProb = 0.5
	self.connectExtendedCells = false
	self.startCellPos = Vec2.new(0,0)
	
	-- max rooms count in X axis
	self.width = w
	
	-- max rooms count in Y axis	
	self.height = h
	
	-- setup SEED
	self.randomSeed = rndSeed
	self._seed_ = useSeed	
	self:SetupSeed()
	
	-- data
	self.data = {}
	self.done = false
	self:_Create2DArray()
	self:_Clean()
	self.connectedCells = {}
	
	return class(self)
end

---------------------------------------------------------
-- Prepare random seed values
---------------------------------------------------------
function TDungeon:SetupSeed()
	
	if (self.randomSeed) then
		self._seed_ = rnd:seed(rnd:next(1,999999999))
	end	
	rnd:seed(self._seed_)
end

---------------------------------------------------------
-- Create 2D cell data array
---------------------------------------------------------
function TDungeon:_Create2DArray()
	for x=0,self.width,1 do
		self.data[x]={}
		for y=0,self.height,1 do
			self.data[x][y] = TDungeonCell:New()
		end
	end
end

---------------------------------------------------------
-- Clean dungeon cells data
---------------------------------------------------------
function TDungeon:_Clean()
	for x=0,self.width,1 do
		for y=0,self.height,1 do
			self.data[x][y]:Clean()
		end
	end
end

---------------------------------------------------------
-- Reset Dungeon
---------------------------------------------------------
function TDungeon:Reset()
	self.current_cell = Vec2.new(0,0)
	self.connectedCells = {}
	self:_Create()
	self:_Clean()
end

---------------------------------------------------------
-- HELPER: show wall exit state 0/1
---------------------------------------------------------
function TDungeon:ToString(_x,_y)
	return ("{"..self.data[_x][_y].up..","..self.data[_x][_y].right..","..self.data[_x][_y].down..","..self.data[_x][_y].left.."}")
end

---------------------------------------------------------
-- HELPER: Show connected cells 
-- [0] - START CELL
-- [n] = [x,y] - next cell position
---------------------------------------------------------
function TDungeon:CellConnectionDump()

	for k,v in ipairs(self.connectedCells) do
 	  	print('ID:'..k..', Cell: ['..v.x..','..v.y..']')
		--self.data[v.x][v.y]:Dump()
		self:ToAsciiRoom(v.x,v.y)
	end
	
end

---------------------------------------------------------
-- HELPER: Show cell data
---------------------------------------------------------
function TDungeon:ToAsciiRoom(x,y)
	local cell={}
	local u,r,d,l,c = '#','#','#','#',' '
	
	if self.data[x][y].up == eSideType.EXIT then u=' ' end
	if self.data[x][y].right == eSideType.EXIT then r=' ' end
	if self.data[x][y].down == eSideType.EXIT then d=' ' end
	if self.data[x][y].left == eSideType.EXIT then l=' ' end

	if self.data[x][y].cellType == eCellType.EXTENDED_CELL then c='E' end
	if self.data[x][y].cellType == eCellType.UNUSED_CELL then c='X' end

	cell[0]='##'..u..'##'
	cell[1]='#   #'
	cell[2]=l..' '..c..' '..r
	cell[3]='#   #'
	cell[4]='##'..d..'##'
		
	print(cell[0])
	print(cell[1])
	print(cell[2])
	print(cell[3])
	print(cell[4])

end

---------------------------------------------------------
-- HELPER: Building dungeon phase 1 
---------------------------------------------------------
function TDungeon:_GenerateMap_Pass1()

	for x=0,self.width,1 do
		for y=0,self.height,1 do
			self.data[x][y]:Pass1()
		end
	end

end

---------------------------------------------------------
-- HELPER: Get start room
---------------------------------------------------------
function TDungeon:_GetStartRoomPosition()
	local cx = 0
	local cy = 0
	
	if self.startSide == eStartSide.TOP then
		cx = rnd:next(1,self.width-1)
		cy = 0
	end

	if self.startSide == eStartSide.RIGHT then
		cx = self.width
		cy = rnd:next(1,self.height-1)
	end
	
	if self.startSide == eStartSide.DOWN then
		cx = rnd:next(1,self.width-1)
		cy = self.height
	end

	if self.startSide == eStartSide.LEFT then
		cx = 0
		cy = rnd:next(1,self.height-1)
	end

	
	self.current_cell = Vec2.new(cx,cy)
end

---------------------------------------------------------
-- HELPER: Check if cell in offset is UNUSED
---------------------------------------------------------
function TDungeon:IsNextCellUnused(diroff)
	local res = false
	
	if self.data[self.current_cell.x+diroff.x][self.current_cell.y+diroff.y].cellType==eCellType.UNUSED_CELL then
		res = true
	end

	return res
end
	
---------------------------------------------------------
-- HELPER: Trace cerlls connection TOP  -> DOWN
---------------------------------------------------------
function TDungeon:_GetNextRoom_From_TOP()

	local dir_offset = Vec2.new(0,0)

	local dir = rnd:next(0,4)
		
	if (dir==0) or (dir==1) then
		-- RIGHT
			dir_offset = Vec2.new(1,0)
			if self.current_cell.x+dir_offset.x>=self.width then
				dir_offset = Vec2.new(0,1)				
			elseif self:IsNextCellUnused(dir_offset)==false then
				dir_offset = Vec2.new(0,1)
			end
	end
	
	if (dir==2) or (dir==3) then
		-- LEFT
			dir_offset = Vec2.new(-1,0)
			if self.current_cell.x+dir_offset.x<0 then
				dir_offset = Vec2.new(0,1)			
			elseif self:IsNextCellUnused(dir_offset)==false then
				dir_offset = Vec2.new(0,1)
			end
	end
	
	if (dir==4) then			
		--DOWN
			dir_offset = Vec2.new(0,1)
	end
		
	self.current_cell = self.current_cell + dir_offset
	
end

---------------------------------------------------------
-- HELPER: Trace cerlls connection RIGHT  -> LEFT
---------------------------------------------------------
function TDungeon:_GetNextRoom_From_RIGHT()


	local dir_offset = Vec2.ZERO
	local dir = rnd:next(0,4)
		
		-- UP
		if (dir==0) or (dir==1) then
			dir_offset = Vec2.new(0,-1)
			if self.current_cell.y+dir_offset.y<0 then
				dir_offset = Vec2.new(-1,0)
			elseif self:IsNextCellUnused(dir_offset)==false then
				dir_offset = Vec2.new(-1,0)
			end
		end
		
		-- DOWN
		if (dir==2) or (dir==3) then
			dir_offset = Vec2.new(0,1)
			if self.current_cell.y+dir_offset.y>=self.height then
				dir_offset = Vec2.new(-1,0)
			elseif self:IsNextCellUnused(dir_offset)==false then
				dir_offset = Vec2.new(-1,0)
			end
		end
			
		-- LEFT
		if (dir==4) then
			dir_offset = Vec2.new(-1,0)
		end
				
	self.current_cell = self.current_cell + dir_offset
	
end

---------------------------------------------------------
-- HELPER: Trace cerlls connection DOWN  -> TOP
---------------------------------------------------------
function TDungeon:_GetNextRoom_From_BOTTOM()

	local dir_offset=Vec2.ZERO
	local dir = rnd:next(0,4)
		

		-- RIGHT
	if (dir==0) or (dir==1) then
		dir_offset = Vec2.new(1,0)
		if self.current_cell.x+dir_offset.x>=self.width then
			dir_offset = Vec2.new(0,-1)
		elseif self:IsNextCellUnused(dir_offset)==false then
			dir_offset = Vec2.new(0,-1)
		end
	end

		-- LEFT
	if (dir==2) or (dir==3) then
		dir_offset = Vec2.new(-1,0)
		if self.current_cell.x+dir_offset.x<0 then
			dir_offset = Vec2.new(0,-1)
		elseif self:IsNextCellUnused(dir_offset)==false then
			dir_offset = Vec2.new(0,-1)
		end
	end			
		-- UP
	if (dir==4) then
		dir_offset = Vec2.new(0,-1)
	end
				
	self.current_cell = self.current_cell + dir_offset
	
end

---------------------------------------------------------
-- HELPER: Trace cerlls connection LEFT  -> RIGHT
---------------------------------------------------------
function TDungeon:_GetNextRoom_From_LEFT()


	local dir_offset = Vec2.ZERO

	local dir = rnd:next(0,4)
		

		-- UP
		if (dir==0) or (dir==1) then
			dir_offset = Vec2.new(0,-1)
			if self.current_cell.y+dir_offset.y<0 then
				dir_offset = Vec2.new(1,0)
			elseif self:IsNextCellUnused(dir_offset)==false then
				dir_offset = Vec2.new(1,0)
			end
		end
	
		-- DOWN
		if (dir==2) or (dir==3) then
			dir_offset = Vec2.new(0,1)
			if self.current_cell.y+dir_offset.y>=self.height then
				dir_offset = Vec2.new(1,0)
			elseif self:IsNextCellUnused(dir_offset)==false then
				dir_offset = Vec2.new(1,0)
			end
		end
			
		-- RIGHT
	if (dir==4) then
		dir_offset = Vec2.new(1,0)
	end
				
	self.current_cell = self.current_cell + dir_offset
	
end

---------------------------------------------------------
-- HELPER: Building dungeon phase 2
---------------------------------------------------------
function TDungeon:_GenerateMap_Pass2()

	self:_GetStartRoomPosition()
	table.insert(self.connectedCells,self.current_cell)
	self.data[self.current_cell.x][self.current_cell.y].cellType=eCellType.LEVEL_CELL
	self.startCellPos = self.current_cell

	-- from TOP -> DOWN
	if  self.startSide == eStartSide.TOP then
		while self.current_cell.y<self.height do
			self:_GetNextRoom_From_TOP()
			self.data[self.current_cell.x][self.current_cell.y].cellType=eCellType.LEVEL_CELL			
			table.insert(self.connectedCells,self.current_cell)
		end
	end
	
	-- from RIGHT -> LEFT
	if  self.startSide == eStartSide.RIGHT  then
		while self.current_cell.x>0 do
			self:_GetNextRoom_From_RIGHT()
			self.data[self.current_cell.x][self.current_cell.y].cellType=eCellType.LEVEL_CELL			
			table.insert(self.connectedCells,self.current_cell)
		end
	end

	-- from BOTTOM -> UP
	if  self.startSide == eStartSide.DOWN then
		while self.current_cell.y>0 do
			self:_GetNextRoom_From_BOTTOM()
			self.data[self.current_cell.x][self.current_cell.y].cellType=eCellType.LEVEL_CELL
			table.insert(self.connectedCells,self.current_cell)
		end
	end

	-- from LEFT -> RIGHT
	if  self.startSide == eStartSide.LEFT then
		while self.current_cell.x<self.width do
			self:_GetNextRoom_From_LEFT()
			self.data[self.current_cell.x][self.current_cell.y].cellType=eCellType.LEVEL_CELL
			table.insert(self.connectedCells,self.current_cell)
		end

	end

end

---------------------------------------------------------
-- HELPER: CONNECT ROOMS and fix wall with EXIT aka ENTRANCE/EXIT/DOOR/CORIDOR/....
---------------------------------------------------------
function TDungeon:GenerateRoomLinksAndDoors()

	local count = 0
	
	for idx,v in pairs(self.connectedCells) do count = count + 1 end
	
	-- START CELL
	local cpos = self.connectedCells[1]
	self.data[cpos.x][cpos.y].prevCell = self.connectedCells[1]
	self.data[cpos.x][cpos.y].currentCell = cpos
	self.data[cpos.x][cpos.y].nextCell = self.connectedCells[2]	
	
	-- PREPARE PREV/NEXT CELL
	for i=2, count,1 do
		cpos = self.connectedCells[i]
		self.data[cpos.x][cpos.y].prevCell = self.connectedCells[i-1]
		self.data[cpos.x][cpos.y].currentCell = cpos
		self.data[cpos.x][cpos.y].nextCell = self.connectedCells[i+1]
	end
	
	-- END CELL

	cpos = self.connectedCells[count]
		
	self.data[cpos.x][cpos.y].prevCell = self.connectedCells[count-1]
	self.data[cpos.x][cpos.y].nextCell = self.connectedCells[count]
	
	-- CONNECT ROOMS and fix wall with EXIT aka ENTRANCE/EXIT/DOOR/CORIDOR/....
	
	for x=0,self.width,1 do
		for y=0,self.height,1 do
			
			if self.data[x][y].cellType == eCellType.LEVEL_CELL then

				local prev_room = self.data[x][y].prevCell-Vec2.new(x,y);
				
				if prev_room==Vec2.LEFT 	then self.data[x][y].left=eSideType.EXIT end
				if prev_room==Vec2.RIGHT 	then self.data[x][y].right=eSideType.EXIT end
				if prev_room==Vec2.UP 		then self.data[x][y].up=eSideType.EXIT end
				if prev_room==Vec2.DOWN 	then  self.data[x][y].down=eSideType.EXIT end
				
				local next_room = self.data[x][y].nextCell-Vec2.new(x,y);

				if next_room==Vec2.LEFT 	then self.data[x][y].left=eSideType.EXIT end
				if next_room==Vec2.RIGHT 	then self.data[x][y].right=eSideType.EXIT end
				if next_room==Vec2.UP 		then self.data[x][y].up=eSideType.EXIT end
				if next_room==Vec2.DOWN 	then self.data[x][y].down=eSideType.EXIT end
			end
		end
	end
					
end

---------------------------------------------------------
-- HELPER: Check if cell is used room with defined type
---------------------------------------------------------
function TDungeon:ExistRoomAt(x, y, x_off,y_off, current_type, conected_type)

	local cx = x + x_off
	local cy = y + y_off

	if self.data[x][y].cellType == current_type then
		if cx<0 then			
			return false
		end
		
		if cy<0 then
			return false
		end
		
		if cx>=self.width then
			return false
		end
		
		if cy>=self.height then
			return false
		end
		
		if self.data[cx][cy].cellType == conected_type then
			return true
		end
	end 

	return false
end

---------------------------------------------------------
-- HELPER: Add extended rooms around main cells by probability
---------------------------------------------------------
function TDungeon:AddExtenedCells()

	for x=0,self.width,1 do
		for y=0,self.height,1 do
		
			local rnd_val =rnd:next()
			
			if rnd_val<self.extendedCellsProb then
			
				if self:ExistRoomAt(x,y,1,0,eCellType.UNUSED_CELL ,eCellType.LEVEL_CELL)==true	then 
					self.data[x][y].cellType = eCellType.EXTENDED_CELL 
				end
				
				if self:ExistRoomAt(x,y,-1,0,eCellType.UNUSED_CELL ,eCellType.LEVEL_CELL)==true	then 
					self.data[x][y].cellType = eCellType.EXTENDED_CELL 
				end
				
				if self:ExistRoomAt(x,y,0,1,eCellType.UNUSED_CELL ,eCellType.LEVEL_CELL)==true	
					then self.data[x][y].cellType = eCellType.EXTENDED_CELL 
				end
				
				if self:ExistRoomAt(x,y,0,-1,eCellType.UNUSED_CELL ,eCellType.LEVEL_CELL)==true	then 
					self.data[x][y].cellType = eCellType.EXTENDED_CELL 
				end
				
			end
		end
	end
end

---------------------------------------------------------
-- HELPER: Add extended rooms around main cells by probability
---------------------------------------------------------
function TDungeon:ConnectExtendedCells()

	for x=0,self.width,1 do
		for y=0,self.height,1 do
			
				if self:ExistRoomAt(x,y,1,0,eCellType.EXTENDED_CELL ,eCellType.LEVEL_CELL)==true  then self.data[x][y].right = eSideType.EXIT end
				if self:ExistRoomAt(x,y,-1,0,eCellType.EXTENDED_CELL ,eCellType.LEVEL_CELL)==true then self.data[x][y].left = eSideType.EXIT end
				if self:ExistRoomAt(x,y,0,1,eCellType.EXTENDED_CELL ,eCellType.LEVEL_CELL)==true  then self.data[x][y].down = eSideType.EXIT end
				if self:ExistRoomAt(x,y,0,-1,eCellType.EXTENDED_CELL ,eCellType.LEVEL_CELL)==true then self.data[x][y].up = eSideType.EXIT end
		end
	end
				
	for x=0,self.width,1 do
		for y=0,self.height,1 do
						
				if self:ExistRoomAt(x,y,1,0,eCellType.LEVEL_CELL ,eCellType.EXTENDED_CELL)  then self.data[x][y].right = eSideType.EXIT end
				if self:ExistRoomAt(x,y,-1,0,eCellType.LEVEL_CELL ,eCellType.EXTENDED_CELL) then self.data[x][y].left = eSideType.EXIT end
				if self:ExistRoomAt(x,y,0,1,eCellType.LEVEL_CELL ,eCellType.EXTENDED_CELL) 	then self.data[x][y].down = eSideType.EXIT end
				if self:ExistRoomAt(x,y,0,-1,eCellType.LEVEL_CELL ,eCellType.EXTENDED_CELL) then self.data[x][y].up = eSideType.EXIT end
		end
	end
end

		
---------------------------------------------------------
-- BUILD dungeon
---------------------------------------------------------
function TDungeon:Build()

	self.done = false
	print('START ...')
	-- prepare dungeon cells - PASS1
	self:_GenerateMap_Pass1()	
	print('.. pass#1 done.')
	
	self:SetupSeed()
	print('.. setup seed done.')
	
	if self.rndStartSide then
		self.startSide = rnd:next(0,3)
	end
	
	-- prepare dungeon cells - PASS2
	self:_GenerateMap_Pass2()	
	print('.. pass#2 done.')
	self.done =true
	
	-- add doors to rooms and add link between rooms - PASS #3
	self:GenerateRoomLinksAndDoors()
	print('.. link doors done.')
	
	-- add extended cells on unused cells - PASS #4
	if self.addExtendedCells==true then 
		self:AddExtenedCells() 
		-- connect extended cells with level cells - PASS #5
		if self.connectExtendedCells==true then 
			self:ConnectExtendedCells() 
		end
		print('.. secret rooms done.')
	end
end


---------------------------------------------------------
-- HELPER: DrawCell
---------------------------------------------------------
function TDungeon:_DrawCell(off_x,off_y,x,y,w,h,col_bkg,col_wall)
	local rx1 = off_x+x*(w+1) 
	local ry1 = off_y+y*(h+1)
	local rx2 = off_x+x*(w+1)+w
	local ry2 = off_y+y*(h+1)+h
	rect(rx1,ry1,rx2,ry2,true,col_bkg)
	rect(rx1,ry1,rx2,ry2,false,col_wall)
end

---------------------------------------------------------
-- HELPER: Draw Door
---------------------------------------------------------
function TDungeon:_DrawDoor(sx,sy,x,y,ox,oy,cell_size,colDoor)
	local px = sx+x*(cell_size+1)+ox 
	local py = sy+y*(cell_size+1)+oy	
	--plot(px,py,colDoor)
	rect(px-1,py-1,px+1,py+1,true,colDoor)
end

---------------------------------------------------------
-- VISUALIZE dungeon
---------------------------------------------------------
function TDungeon:Visualize(sx,sy)

	local cell_size = 8
	local spacing = 6
	local colCell = Color.new(32,32,32)
	local colUnused = Color.new(0,0,0)
	local colLevelWall = Color.new(255,255,255)
	local colExtWall = Color.new(128,0,255)
	local colDoor = Color.new(32,32,32)

	-- DRAW GRID
	
	for x=0,self.width,1 do
		for y=0,self.height,1 do
			self:_DrawCell(sx,sy,x,y,cell_size,cell_size,colCell,colUnused)
		end
	end	
	
	-- DRAW ROOM/CELLS
	for k,v in ipairs(self.connectedCells) do
		if (self.data[v.x][v.y].cellType == eCellType.LEVEL_CELL) then self:_DrawCell(sx,sy,v.x,v.y,cell_size,cell_size,colCell,colLevelWall) end
		
	end
	
	-- DRAW EXTENDED ROOM/CELLS 
	for x=0,self.width,1 do
		for y=0,self.height,1 do
			if (self.data[x][y].cellType == eCellType.EXTENDED_CELL) then self:_DrawCell(sx,sy,x,y,cell_size,cell_size,colCell,colExtWall) end
		end
	end	

	for x=0,self.width,1 do
		for y=0,self.height,1 do
			if (self.data[x][y].cellType == eCellType.LEVEL_CELL) then 
				if  self.data[x][y].up 		== eSideType.EXIT then  self:_DrawDoor(sx,sy,x,y,cell_size/2,0,cell_size,colDoor)  end				
				if  self.data[x][y].right 	== eSideType.EXIT then  self:_DrawDoor(sx,sy,x,y,cell_size,cell_size/2,cell_size,colDoor)  end
				if  self.data[x][y].down 	== eSideType.EXIT then  self:_DrawDoor(sx,sy,x,y,cell_size/2,cell_size,cell_size,colDoor)  end
				if  self.data[x][y].left 	== eSideType.EXIT then  self:_DrawDoor(sx,sy,x,y,0,cell_size/2,cell_size,colDoor)  end
			end	
				
			if (self.data[x][y].cellType == eCellType.EXTENDED_CELL) then 
				if  self.data[x][y].up 		== eSideType.EXIT then  self:_DrawDoor(sx,sy,x,y,cell_size/2,0,cell_size,colDoor)  end				
				if  self.data[x][y].right 	== eSideType.EXIT then  self:_DrawDoor(sx,sy,x,y,cell_size,cell_size/2,cell_size,colDoor)  end
				if  self.data[x][y].down 	== eSideType.EXIT then  self:_DrawDoor(sx,sy,x,y,cell_size/2,cell_size,cell_size,colDoor)  end
				if  self.data[x][y].left 	== eSideType.EXIT then  self:_DrawDoor(sx,sy,x,y,0,cell_size/2,cell_size,colDoor)  end
			end	
		end
	end
		
	
	-- TODO
	-- fix extended cell doors builder

end