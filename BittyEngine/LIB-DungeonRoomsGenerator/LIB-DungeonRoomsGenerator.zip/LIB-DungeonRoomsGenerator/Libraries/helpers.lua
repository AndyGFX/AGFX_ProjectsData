
Vec2.ONE = Vec2.new(1,1)
Vec2.ZERO = Vec2.new(0,0)
Vec2.LEFT = Vec2.new(-1,0)
Vec2.UP = Vec2.new(0,-1)
Vec2.DOWN = Vec2.new(0,1)
Vec2.RIGHT = Vec2.new(1,0)

print ("helpers.lua loaded ...")