
require 'Libraries/TDungeon'

-- define colors
local c_bkg  = Color.new(255,255,255)
local color1 = Color.new(0,255,255)
local color2 = Color.new(255,80,80)
local fnt = Font.new('Fonts/pixelmix.ttf',8)
local dungeon = nil

function setup()

	-- prepare canvas
	local canvas= nil
	canvas = Canvas.main
	canvas:resize(320,200)
	
	-- create dungeon object
	dungeon = TDungeon:New(6,6,false,17061965)
	
	-- setup generator	
	dungeon.startSide = eStartSide.TOP		-- room start from: eStartSide.TOP | eStartSide.RIGHT | eStartSide.DOWN | eStartSide.LEFT
	dungeon.rndStartSide = false				-- true = randomize seed | false = generate from user defined seed
	dungeon.addExtendedCells = true			-- true = add secret rooms | false = disable
	dungeon.extendedCellsProb = 0.25		-- 0 - 1.0 = probability for secret rooms
	dungeon.connectExtendedCells = true		-- true = create door | false = without doors
	
	-- generate dungeon	
	dungeon:Build()
	
	dungeon:CellConnectionDump()
	
end

function update(delta)
	-- set font
	font(fnt)
	text('DEMO: TDungeon class',0,0)
	
	dungeon:Visualize(16,16)
	
end
