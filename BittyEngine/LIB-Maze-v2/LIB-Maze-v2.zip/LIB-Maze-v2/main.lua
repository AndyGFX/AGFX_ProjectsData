
require 'Libraries/TMaze'

-- define colors
local color1 = Color.new(0,255,255)
local color2 = Color.new(255,80,80)
local fnt = Font.new('Fonts/pixelmix.ttf',8)
local maze = nil

function setup()

	-- prepare canvas
	local canvas= nil
	canvas = Canvas.main
	canvas:resize(320,200)
	
	-- create maze object
	maze = TMaze:New(65,65,false,2021,true)
	maze:Build()
	
end

function update(delta)
	-- set font
	font(fnt)
	text('DEMO: TMaze v 2.0 class',0,0)
	
	-- preview maze data
	maze:Preview(16,16,color1);
end
