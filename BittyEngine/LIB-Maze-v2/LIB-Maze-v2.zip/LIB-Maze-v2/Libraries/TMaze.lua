
-- TMaze v2.0 [AndyGFX] ------------------------------------------------------

--[[


Example:

	maze = TMaze:New(32,32,true,2022,false)
	maze:Build()

]]

-- Define TMaze class ---------------------------------------------
require 'Libraries/class'
TMaze = {}

rnd = Random.new()
local g_intDepth=0

---------------------------------------------------------
-- CONTRUCTOR 
--------------------------------------------------------- 

function TMaze:New(w,h,rndSeed,useed,invert) 

    self.width = w
    self.height = h
	self.invert = invert
	
	-- setup SEED
	self.randomSeed = rndSeed
	self._seed_ = useSeed	
	
	-- data
	self.data = {}
	self.done = false
	self:_Create2DArray()
	self:_Clean()
		        
    return class(self)

end   


---------------------------------------------------------
-- Prepare random seed values
---------------------------------------------------------
function TMaze:SetupSeed()
	
	if (self.randomSeed) then
		self._seed_ = rnd:seed(rnd:next(1,999999999))
	end	
	rnd:seed(self._seed_)
end

---------------------------------------------------------
-- Create 2D cell data array
---------------------------------------------------------
function TMaze:_Create2DArray()
	for x=0,self.width,1 do
		self.data[x]={}
		for y=0,self.height,1 do
			self.data[x][y] = {}
		end
	end
end

---------------------------------------------------------
-- Clean dungeon cells data
---------------------------------------------------------
function TMaze:_Clean()
	for x=0,self.width,1 do
		for y=0,self.height,1 do
			self.data[x][y].value = 0
		end
	end
end

function TMaze:ValidMove( x, y)
	
	local intResult = 0; 
	if (x>=0 and x<self.width and y>=0 and y<self.height and self.data[x][y].value == 0) then
		intResult = 1
	end
	return intResult
end

function TMaze:ValidCount( x, y)
	
	local intResult = 0
 
	local res = self:ValidMove( x,y-2)
	intResult = intResult + self:ValidMove( x,y-2)
	intResult = intResult + self:ValidMove( x+2,y) 
	intResult = intResult + self:ValidMove( x,y+2) 
	intResult = intResult + self:ValidMove( x-2,y) 
 
	return intResult; 
end

function TMaze:DigMaze(x, y)
	
	local newx = 0; 
	local newy = 0; 
	
	g_intDepth = g_intDepth + 1; 
 
	self.data[x][y].value = 1
	
	local intCount = self:ValidCount( x, y)
	
	while (intCount > 0) do
		local randi = rnd:next(0,3)
		
			if randi==0 then
				if (self:ValidMove(x,y-2) > 0) then
					self.data[x][y-1].value = 1
					self:DigMaze(x,y-2) 
				end
			end
			
			if randi==1 then
				if (self:ValidMove(x+2,y) > 0) then
					self.data[x+1][y].value = 1; 
					self:DigMaze( x+2,y)
				end
			end

			if randi==2 then
				if (self:ValidMove(x,y+2) > 0) then
					self.data[x][y+1].value = 1
					self:DigMaze( x,y+2)
				end
			end
			
			if randi==3 then
				if (self:ValidMove( x-2,y) > 0) then
					self.data[x-1][y].value = 1 
					self:DigMaze ( x-2,y)
				end
			end

		intCount = self:ValidCount( x, y)
	end
		
	g_intDepth = g_intDepth - 1
	
end

function TMaze:InvertMaze()
 	for i=0,self.width-1 do
 		for j=0,self.height-1 do
 		
 	 		if self.data[i][j].value==0 then 	   	  		
 	  			self.data[i][j].value=1
			else
 	  			self.data[i][j].value=0
 	 		end
 		end
 	end
end

function TMaze:GenerateMap()
	
	g_intDepth = 0; 
	
	self:SetupSeed()
	self:DigMaze(1, 1); 
	if (self.invert==true) then
		self:InvertMaze()
	end
	
end

---------------------------------------------------------
-- BUILD
---------------------------------------------------------
function TMaze:Build()
	self.done=false
	self:GenerateMap()
	self.done=true
end

function TMaze:Preview(ox,oy,color1)
	
 
 	for i=0,self.width-1 do
 		for j=0,self.height-1 do
 		
 	 		if self.data[i][j].value==0 then 	   	  		
 	  			plot(ox+j,oy+i,Color.new(0,0,0))
			else
 	  			plot(ox+j,oy+i,color1)
 	 		end
 		end
 	end
end