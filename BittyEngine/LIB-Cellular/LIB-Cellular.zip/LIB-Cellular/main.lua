require 'Libraries/class'
require 'Libraries/TCellular'

-- define colors
local c_bkg = Color.new(255,255,255)
local color1 = Color.new(0,255,255)
local color2 = Color.new(255,80,80)
local fnt = Font.new('Fonts/pixelmix.ttf',8)
local cave1 = nil
local cave2 = nil

function setup()

	-- prepare canvas
	local canvas= nil
	canvas = Canvas.main
	canvas:resize(320,200)
	
	-- create cellular object #1
	cave1 = TCellular:New()
	cave1:Generate(64,32,0.6,3,5,5) 

	-- create cellular object #2
	cave2 =TCellular:New()
	cave2:Generate(64,32,0.5,3,5,5) 
	
end

function update(delta)
	-- set font
	font(fnt)
	text('DEMO: TCellular class',0,0)
	
	-- preview cellular data
	cave1:PreviewMap(0,16,c_bkg,color1)
	cave2:PreviewMap(0,16+33,c_bkg,color2)
end
