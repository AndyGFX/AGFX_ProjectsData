require 'Libraries/Game/TGameOfLife'

local retro_fnt = Font.new('Fonts/pixelmix.ttf',8)

local game_of_life = {}

function setup()
	-- prepare canvas
	local canvas= nil
	canvas = Canvas.main
	canvas:resize(640,480)
	
	
	game_of_life = TGameOfLife:New(640,480,6,8)
	game_of_life.interval = 0.1
	game_of_life:Initialize()


	
end

function update(delta)
	-- set font
	game_of_life:Draw(delta)
	font(retro_fnt)
	text('Project: Game Of Life',0,0)
	
end
