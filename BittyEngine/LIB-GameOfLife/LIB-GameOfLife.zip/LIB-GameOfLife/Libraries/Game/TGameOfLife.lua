require 'Libraries/class'
TGameOfLife = class()


function TGameOfLife:New(cw,ch,cs,coff)

	print(cw)
	self.canvasSize = Vec2.new(cw,ch)
	self.cellSize = cs
	self.cellOffset = coff  -- spacing
	self.interval = 1
	self.counter = 0
	self.colorAlive = Color.new(0,200,0)
	self.colorDead =  Color.new(0,0,0)
	self.cellsCount = Vec2.new(self.canvasSize.x/self.cellSize,self.canvasSize.y/self.cellSize)
	self.cells = {}
	self.cellsBuffer = {}
	self.probabilityOfAliveAtStart = 50
	self.rnd = Random.new()
	self:CreateCells()
	self:CreateCellsBuffer()
	
	return class(self)
end

function TGameOfLife:CreateCells()


	for x=0,self.cellsCount.x,1 do
		self.cells[x]={}
		for y=0,self.cellsCount.y,1 do
			self.cells[x][y] = 0
		end
	end
	
end

function TGameOfLife:CreateCellsBuffer()

	for x=0,self.cellsCount.x,1 do
		self.cellsBuffer[x]={}
		for y=0,self.cellsCount.y,1 do
			self.cellsBuffer[x][y] = 0
		end
	end
	
end


function TGameOfLife:Clear()


	for x=0,self.cellsCount.x,1 do
		self.cells[x]={}
		for y=0,self.cellsCount.y,1 do
			self.cells[x][y] = 0
			self.cellsBuffer[x][y] = 0
		end
	end
	
end

function TGameOfLife:Initialize()

	for x=0,self.cellsCount.x,1 do
		for y=0,self.cellsCount.y,1 do
		
			local state = self.rnd:next(0,100)		
			if (state>self.probabilityOfAliveAtStart) then
				self.cells[x][y] = 0
			else
				self.cells[x][y] = 1
			end
		end
	end
	
end

function TGameOfLife:Draw(delta)

	for x=0,self.cellsCount.x,1 do
		for y=0,self.cellsCount.y,1 do
		
			local cx = x*self.cellOffset
			local cy = y*self.cellOffset
			
			if self.cells[x][y]==1 then
				rect(cx,cy,cx+self.cellSize-1,cy+self.cellSize-1,true, self.colorAlive)
				--plot(cx,cy,self.alive)
			else
				rect(cx,cy,cx+self.cellSize-1,cy+self.cellSize-1,true,self.colorDead)
				--plot(cx,cy,self.dead)
			end
		end
	end
	
	if self.counter >self.interval then
		self:Iteration()
		self.counter = 0
	end
	
	
	self.counter = self.counter + delta
	
end


function TGameOfLife:Iteration() 
  -- When the clock ticks
  -- Save cells to buffer (so we opeate with one array keeping the other intact)
  for x=0, self.cellsCount.x, 1 do
    for y=0, self.cellsCount.y, 1 do 
      self.cellsBuffer[x][y] = self.cells[x][y];
    end
  end

  -- Visit each cell:
  for x=0, self.cellsCount.x, 1 do
    for y=0, self.cellsCount.y, 1 do
      -- And visit all the neighbours of each cell
      local neighbours = 0 -- We'll count the neighbours
      for xx=x-1, x+1,1 do
        for yy=y-1 , y+1,1 do   
          if (((xx>=0) and (xx<self.cellsCount.x)) and ((yy>=0) and (yy<self.cellsCount.y))) then -- Make sure you are not out of bounds
            if (not((xx==x)and(yy==y))) then -- Make sure to to check against self
              if (self.cellsBuffer[xx][yy]==1) then
                neighbours =  neighbours+1 -- Check alive neighbours and count them
              end
            end -- End of if
          end -- End of if
        end -- End of yy loop
      end --End of xx loop
      -- We've checked the neigbours: apply rules!
      if (self.cellsBuffer[x][y]==1) then
	    -- The cell is alive: kill it if necessary
        if (neighbours < 2 or neighbours > 3) then
          self.cells[x][y] = 0   -- Die unless it has 2 or 3 neighbours
        end
      else -- The cell is dead: make it live if necessary      
        if (neighbours == 3 ) then
          self.cells[x][y] = 1 -- Only if it has 3 neighbours
        end
      end -- End of if
    end -- End of y loop
  end -- End of x loop
end -- End of function
