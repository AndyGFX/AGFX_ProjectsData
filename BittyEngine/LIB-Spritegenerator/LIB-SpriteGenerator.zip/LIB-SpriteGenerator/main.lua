require 'Libraries/TSpriteGen'

local retro_fnt = Font.new('Fonts/pixelmix.ttf',8)

local A_sprites = {}
local B_sprites = {}
local C_sprites = {}

local cSTATIC = Color.new(255,128,0)
local cVOID = Color.new(128,128,255)
local cSOLID = Color.new(255,255,255)
local cOUTLINE = Color.new(0,0,0,255)
local cEMPTY = Color.new(0,0,0,0)
local scount = 8
function setup()
	-- prepare canvas
	local canvas= nil
	canvas = Canvas.main
	canvas:resize(320,200)
	
	for i=0,scount do
		A_sprites[i] = TSpriteGen:New('Data/SpriteMasks/Ship.map',2022+i,0.5,0.2)
		A_sprites[i]:SetColors(cEMPTY,cSTATIC,cVOID,cSOLID,cOUTLINE)
		A_sprites[i]:Generate()

		B_sprites[i] = TSpriteGen:New('Data/SpriteMasks/Ship2.map',2022+i,0.5,0.2)
		B_sprites[i]:SetColors(cEMPTY,cSTATIC,cVOID,cSOLID,cOUTLINE)
		B_sprites[i]:Generate()

		C_sprites[i] = TSpriteGen:New('Data/SpriteMasks/Body.map',2022+i,0.5,0.2)
		C_sprites[i]:SetColors(cEMPTY,cSTATIC,cVOID,cSOLID,cOUTLINE)
		C_sprites[i]:Generate()


		
	end
--	sprite:DumpTemplate()
	
end

function update(delta)
	-- set font
	font(retro_fnt)
	text('Project: Procedural sprite generator',0,0)
	for i=0,scount do
		A_sprites[i]:Draw(10+34*i,32*1,32,32)
		B_sprites[i]:Draw(10+34*i,34*2,32,32)
		C_sprites[i]:Draw(10+34*i,34*3,32,32)
	end
end
