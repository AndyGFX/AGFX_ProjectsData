require('Libraries/class')


TGame = {}


-- enums

GameMode= {}
GameMode.START = 0
GameMode.SPLASH = 1
GameMode.TITLE = 2
GameMode.STARTGAME = 3
GameMode.PLAYGAME = 4
GameMode.PAUSEGAME = 5
GameMode.ENDGAME = 6


function TGame:New()

	self.mode = GameMode.START
	self.Draw_Splash = nil
	self.Draw_Title = nil
	self.Draw_StartGame = nil
	self.Draw_PlayGame = nil
	self.Draw_PauseGame = nil
	self.Draw_EndGame = nil
	
	return class(self)
	
end


function TGame:SetMode(m)
	self.mode=m
end


function TGame:Update(delta)

	local mode = self.mode
	
	if self.Draw_Splash~=nill and mode == GameMode.SPLASH then self.Draw_Splash(delta) end
	if self.Draw_Title~=nill and mode == GameMode.TITLE then self.Draw_Title(delta) end
	
	if self.Draw_StartGame~=nill and mode == GameMode.STARTGAME then self.Draw_StartGame(delta) end
	if self.Draw_PlayGame~=nill and mode == GameMode.PLAYGAME then self.Draw_PlayGame(delta) end
	if self.Draw_PauseGame~=nill and mode == GameMode.PAUSEGAME then self.Draw_PauseGame(delta) end
	if self.Draw_EndGame~=nill and mode == GameMode.ENDGAME then self.Draw_EndGame(delta) end			
	
end


print ('CLASS: TGame loaded ...')