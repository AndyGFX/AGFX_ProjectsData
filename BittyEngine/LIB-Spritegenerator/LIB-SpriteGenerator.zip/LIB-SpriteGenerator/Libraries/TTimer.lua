require('Libraries/class')


TTimer = {}


function TTimer:New()

	self.time = 0;
	self.enabled = false
	self.delay = 0.2
	self.OnStart = nil
	self.OnTimer = nil
	return class(self)
end

function TTimer:Start()

	self.enabled=true
end

function TTimer:Pause()
	self.enabled=false
end

function TTimer:Stop()
	self.enabled=false
	self.time=0
end


function TTimer:Update(delta)

	if self.enabled == true then
		self.time = self.time + delta
		
		if (self.time>self.delay) then
			self.time = 0
			if (self.OnTimer~=nil) then 
				self.OnTimer() 
			else 
				print("TTimer: Undefined callback for TTimer.OnTimer");
			end
		end
	end

end

print ('CLASS: TTimer loaded ...')