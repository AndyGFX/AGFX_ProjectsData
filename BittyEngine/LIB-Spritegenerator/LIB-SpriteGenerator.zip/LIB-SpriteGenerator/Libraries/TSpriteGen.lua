-- Define Procedural Sprite Generator class ---------------------------------------------
require 'Libraries/class'
require 'Libraries/TSeed'

-- TILE ID = 0 = Always EMPTY						 0
-- TILE ID = 1 = Always STATIC - RED				  -1	
-- TILE ID = 2 = Always EMPTY/VOID by seed - GREEN	1
-- TILE ID = 3 = Always EMPTY/SOLID by seed - BLUE	2
-- TILE ID = 5 = X-axis MIRROR

TSpriteGen = {}

function TSpriteGen:New(template,rndSeed,void_balance,solid_balance)

	self.mask = {}
	self.template_res = Resources.load(template)
	self.w = self.template_res.width
	self.wh = self.template_res.width/2
	self.h = self.template_res.height
	self.img = Image.new()
	self.img:resize(self.w,self.h)
	self.texture = nil
	self.balance_solid = solid_balance
	self.balance_void = void_balance
	self.color_STATIC = Color.new(255,0,0)
	self.color_VOID = Color.new(0,255,0)
	self.color_SOLID = Color.new(0,0,255)
	self.color_OUTLINE = Color.new(0,0,0,255)
	self.color_EMPTY = Color.new(0,0,0,0)
	
	-- setup SEED	
	self.seed = TSeed:New()
	self.seed:Setup(rndSeed)
	
	
	return class(self)
end

function TSpriteGen:SetColors(cEmpty,cStatic,cVoid,cSolid,cOutline)
	self.color_STATIC = cStatic
	self.color_VOID = cVoid
	self.color_SOLID = cSolid
	self.color_OUTLINE = cOutline
	self.color_EMPTY = cEmpty
end

function TSpriteGen:Generate()

	self:Blank()
	self:CreateBody()
	self:CreateEdges()
	self:AddColors()

end



function TSpriteGen:Blank()

	for x=0,self.w-1 do
		self.mask[x]={}
		for y=0,self.h-1 do
			self.mask[x][y] = 0
		end
	end
	
end

function TSpriteGen:CreateBody()

	local rgb = 0

	
	for y=0,self.h-1 do
		for x=0,self.w-1 do

			rgb = mget(self.template_res,x,y)
			
		
			if (rgb==2) then
				if self.seed:Get()>self.balance_solid then 
					rgb = 0 
				end
			elseif (rgb==3) then
				if (self.seed:Get()>self.balance_void) then
					rgb = 3
				else
					rgb = 2
				end
			end
			-- APPLY data and MIRROR H if is used
			self.mask[x][y] = rgb
			if (rgb==5) then
				self.mask[x][y]=self.mask[self.w-x-1][y]
			end
		end
	end
	for x=0,self.w-1 do
		for y=0,self.h-1 do		
			if (self.mask[x][y]==4) then
				self.mask[x][y]=self.mask[x][self.h-y-1]
			end
		end
	end	
	
end

function TSpriteGen:CreateEdges()
	for y=0,self.h-1,1 do
		for x=0,self.w-1,1 do
			if self.mask[x][y]==2  then				
				if x-1 >= 0 and self.mask[x-1][y] == 0 then
	            	self.mask[x-1][y] = -1
	          	end 
				  
	          	if x+1<self.w and self.mask[x+1][y] == 0 then
	              	self.mask[x+1][y] = -1
	          	end    

	          	if y-1 >= 0 and self.mask[x][y-1] == 0 then
	              	self.mask[x][y-1] = -1
	          	end    
	          	if y+1 < self.h and self.mask[x][y+1] == 0 then
	              	self.mask[x][y+1] = -1
	          	end

			end
		end
	end
	
end

function TSpriteGen:AddColors()

	
	for y=0,self.h-1,1 do
		for x=0,self.w-1,1 do
		
			self.img:set(x, y, self.color_EMPTY)
			
			if self.mask[x][y] == 1 then self.img:set(x, y, self.color_STATIC) end			
			if self.mask[x][y] == 2 then self.img:set(x, y, self.color_VOID) end
			if self.mask[x][y] == 3 then self.img:set(x, y, self.color_SOLID) end			
			if self.mask[x][y] == -1 then self.img:set(x, y, self.color_OUTLINE) end
			if self.mask[x][y] == 0 then self.img:set(x, y, EMPTY) end
		end
	end
	self.texture = Resources.load(self.img);
end

function TSpriteGen:Draw(x,y,w,h)
	tex(self.texture,x,y,w,h)
end
---------------------------------------------------------------
-- Dump map data to log file
---------------------------------------------------------------
function TSpriteGen:DumpMask()
	for x=0,self.w-1 do
		local line = "";
		for y=0,self.h-1 do
			if (self.mask[y][x]==-1) then line = line..'H'; end
			if (self.mask[y][x]==0) then line = line..' '; end
			if (self.mask[y][x]==1) then line = line..'R'; end
			if (self.mask[y][x]==2) then line = line..'G'; end
			if (self.mask[y][x]==3) then line = line..'B'; end
			if (self.mask[y][x]==4) then line = line..'-'; end
			if (self.mask[y][x]==5) then line = line..'|'; end
		end
		print(line);
	end
end

function TSpriteGen:DumpTemplate()
	for x=0,self.w-1,1 do
		local line = "";
		for y=0,self.h-1,1 do
			if (mget(self.template_res,y,x)==0) then line = line..' '; end
			if (mget(self.template_res,y,x)==1) then line = line..'R'; end
			if (mget(self.template_res,y,x)==2) then line = line..'G'; end
			if (mget(self.template_res,y,x)==3) then line = line..'B'; end
			if (mget(self.template_res,y,x)==4) then line = line..'-'; end
			if (mget(self.template_res,y,x)==5) then line = line..'|'; end
		end
		print(line);
	end
end
