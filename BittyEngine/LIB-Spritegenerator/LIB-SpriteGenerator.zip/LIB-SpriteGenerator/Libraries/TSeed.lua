require 'Libraries/class'

TSeed = {}

function TSeed:New()

	self.rnd=Random.new()
	self._seed_ = nil	
	
	return class(self)
	
end

function TSeed:Setup(seed_value)
	
	-- RND SEED
	if (seed_value==0) then
		self._seed_ = self.rnd:seed(self.rnd:next(1,999999999))
	else
		self._seed_ = seed_value
		self.rnd:seed(self._seed_)
	end
	
end

function TSeed:Get()
	return self.rnd:next()
end

function TSeed:GetNext(hi)
	return self.rnd:next(hi)
end

function TSeed:GetNext(low,hi)
	return self.rnd:next(low,hi)
end



