require('Libraries/TCellular')
require('Libraries/TMarchingSquare')

local retro_fnt = Font.new('Fonts/pixelmix.ttf',8)


theme1 = {}
tid = 32
theme1[01] = {tile = tid+0,flag=-1}
theme1[02] = {tile = tid+1,flag=-1}
theme1[03] = {tile = tid+2,flag=-1}
theme1[04] = {tile = tid+3,flag=-1}
theme1[05] = {tile = tid+4,flag=-1}
theme1[06] = {tile = tid+5,flag=-1}
theme1[07] = {tile = tid+6,flag=-1}
theme1[08] = {tile = tid+7,flag=-1}
theme1[09] = {tile = tid+8,flag=-1}
theme1[10] = {tile = tid+9,flag=-1}
theme1[11] = {tile = tid+10,flag=-1}
theme1[12] = {tile = tid+11,flag=-1}
theme1[13] = {tile = tid+12,flag=-1}
theme1[14] = {tile = tid+13,flag=-1}
theme1[15] = {tile = tid+14,flag=-1}
theme1[16] = {tile = tid+15,flag=-1}

cave = TCellular:New(); 
COLOR_BLACK = Color.new(0,0,0)
COLOR_RED = Color.new(255,0,0)
COLOR_WHITE = Color.new(255,255,255) 

function setup()
	-- prepare canvas
	local canvas= nil
	canvas = Canvas.main
	canvas:resize(320,200)
	
	cave:Generate(32,25,0.6,3,5,5);
	marchingSquares = TMarchingSquare:New();
	marchingSquares.map_res = Resources.load('Data/Tilemap.map')
	marchingSquares.theme = theme1;
	marchingSquares.invert = true;
	marchingSquares.mapData = cave;
	marchingSquares:BuildTilemap();
	
end

function update(delta)
	-- set font
	font(retro_fnt)
	text('Project: TMarchingSquare 4x4',0,0)
	cave:PreviewMap(320-32,0,COLOR_BLACK,COLOR_WHITE)
	map(marchingSquares.map_res,0,16,COLOR_WHITE,1,1)
end
