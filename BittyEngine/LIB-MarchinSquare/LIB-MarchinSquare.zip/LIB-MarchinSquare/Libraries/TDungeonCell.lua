require 'math'
require 'Libraries/class'


TDungeonCell = {}
TDungeonCell = class()

-- ENUMS
eSideType = {}
eSideType.WALL = 1
eSideType.EXIT = 0

eStartSide = {}
eStartSide.TOP = 0
eStartSide.RIGHT = 1
eStartSide.DOWN = 2
eStartSide.LEFT = 3

eCellType = {}
eCellType.UNUSED_CELL = 0
eCellType.LEVEL_CELL = 1
eCellType.EXTENDED_CELL = 2

eDirecrtions = {}
eDirecrtions.UP = 0
eDirecrtions.RIGHT = 1
eDirecrtions.DOWN = 2
eDirecrtions.LEFT = 3



function TDungeonCell:New()
	self.up			= eSideType.EXIT
	self.right		= eSideType.EXIT
	self.down		= eSideType.EXIT
	self.left		= eSideType.EXIT
	self.visited	= 0
	self.cellType	= eCellType.UNUSED_CELL
	self.nextCell	= Vec2.new(0,0)
	self.currentCell= Vec2.new(0,0)
	self.prevCell	= Vec2.new(0,0)
	self.userData	= {}
	
	return class(self)
	
end

function TDungeonCell:Clean()
	self.up			= eSideType.EXIT
	self.right		= eSideType.EXIT
	self.down		= eSideType.EXIT
	self.left		= eSideType.EXIT
	self.visited	= 0
	self.cellType	= eCellType.UNUSED_CELL
	self.nextCell	= Vec2.new(0,0)
	self.currentCell= Vec2.new(0,0)
	self.prevCell	= Vec2.new(0,0)
	self.userData	= {}
end

function TDungeonCell:Pass1()
	self.up			= eSideType.WALL
	self.right		= eSideType.WALL
	self.down		= eSideType.WALL
	self.left		= eSideType.WALL
	self.cellType	= eCellType.UNUSED_CELL
end
 
function TDungeonCell:Dump()
	print('-- CELL --------------------')
	print('Side UP       :   '..self.up)
	print('Side RIGHT    :   '..self.right)
	print('Side DOWN     :   '..self.down)
	print('Side LEFT     :   '..self.left)
	print('Visited       :   '..self.visited)
	
	if (self.cellType==0) then print('Cell TYPE     :   '..self.cellType..' - UNUSED') end
	if (self.cellType==1) then print('Cell TYPE     :   '..self.cellType..' - LEVEL') end
	if (self.cellType==2) then print('Cell TYPE     :   '..self.cellType..' - EXTENDED') end
	
	
	--print('Cell TYPE     :   '..self.cellType)
	print('Prev. CELL    :   ['..self.prevCell.x..','..self.prevCell.y..']')
	print('Current CELL  :   ['..self.currentCell.x..','..self.currentCell.y..']')
	print('Next CELL     :   ['..self.nextCell.x..','..self.nextCell.y..']')
	
end

print ('CLASS: TDungeonCell loaded ...')